/* primjer ispisuje pozdravnu poruku "Pozdrav svijetu!" */

/* pretprocesorski dio */
#include <stdio.h>

/* glavni program - funkcija main() */
int main() 
{
	printf("Pozdrav svijetu!\n");
	
	return 0;
}
