/* Napravi program koji unosi cijeli broj u dekadskom zapisu i ispisuje koliko se 
   puta u njegovom binarnom zapisu pojavljuje znamenka 1 */

#include <stdio.h>

int main() 
{
	int dek_broj, pom_broj, bin_zn[32] = {}, i = 31, brojac = 0;
	
	/* unos broja */
	printf("Unesi broj u dekadskom zapisu: ");
	scanf("%d", &dek_broj);
	pom_broj = dek_broj;
	
	/* pretvaranje u binarni zapis */
	while(pom_broj != 0)
	{
		bin_zn[i] = pom_broj % 2;
		pom_broj /= 2;
		i--;
	}
	
	/* ispis broja u binarnom zapisu */
	printf("(%d)10 = ("), dek_broj;
	for(i = 0; i < 32; i++)
	{
		printf("%d", bin_zn[i]);
	}
	printf(")2\n");
	
	/* prebrojavanje 1 u binarnom zapisu */
	for(i = 0; i < 32; i++)
	{
		if(bin_zn[i] == 1)
		{	
			brojac++;
		}	
	}
	printf("U binarnom zapisu broja %d ima %d jedinica.\n", dek_broj, brojac);
	return 0;
}
