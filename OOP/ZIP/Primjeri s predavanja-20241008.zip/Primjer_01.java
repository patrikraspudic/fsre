// primjer ispisuje pozdravnu poruku

package Primjer_01;

public class Primjer_01 
{
	// glavni program, tj. funkcija main smije se nalaziti samo u jednom razredu Java projekta
	public static void main(String [] args)
	{
		System.out.println("Pozdrav svijetu!");
	}
}
