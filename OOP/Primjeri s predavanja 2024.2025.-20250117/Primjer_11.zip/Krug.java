package Primjer_11;

// razred Krug implementira su�elje GeometrijskiLik i Transformacija
public class Krug implements GeometrijskiLik, Transformacija
{
	public Tocka srediste;
	public double polumjer;
	
	public Krug(Tocka srediste, double polumjer)
	{
		this.srediste = srediste;
		this.polumjer = polumjer;
	}
	
	public Krug(final Krug K)
	{
		this.srediste = K.srediste;	
		this.polumjer = K.polumjer;
	}
	
	public void promijeniPolumjer(double noviPolumjer)
	{
		this.polumjer = noviPolumjer;
	}
	
	// implementacija metode su�elja GeometrijskiLik
	public double povrsina()
	{
		return this.polumjer * this.polumjer * Math.PI;
	}
	
	// implementacija metode su�elja GeometrijskiLik
	public double opseg()
	{
		return 2 * this.polumjer * Math.PI;
	}	
	
	// implementacija metode su�elja Transformacija
	public void pomak(double dx, double dy)
	{
		this.srediste.pomak(dx, dy);
	}
	
	public Kvadrat opisaniKvadrat()
	{
		return new Kvadrat(this.srediste, 2 * this.polumjer);
	}
		
	public String toString()
	{
		return "krug sa sredistem u " + this.srediste + " i polumjera " + this.polumjer;
	}
}
