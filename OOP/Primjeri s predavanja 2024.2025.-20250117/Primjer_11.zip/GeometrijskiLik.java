package Primjer_11;

public interface GeometrijskiLik 
{
	double povrsina();
	double opseg();
}
