package Primjer_11;

// razred Pravokutnik implementira su�elje GeometrijskiLik
public class Pravokutnik implements GeometrijskiLik
{
	public Tocka srediste;
	public double sirina;
	public double visina;
		
	public Pravokutnik(Tocka srediste, double sirina, double visina)
	{
		this.srediste = srediste;
		this.visina = visina;
		this.sirina = sirina;
	}
	
	public Pravokutnik(final Pravokutnik P)
	{
		this.srediste = P.srediste;
		this.sirina = P.sirina;
		this.visina = P.visina;
	}
	
	// implementacija metode su�elja GeometrijskiLik
	public double povrsina()
	{
		return this.visina * this.sirina;
	}

	// implementacija metode su�elja GeometrijskiLik	
	public double opseg()
	{
		return 2 * (this.visina + this.sirina);
	}	
	
	public double dijagonala()
	{
		return Math.sqrt(this.sirina * this.sirina + this.visina * this.visina);
	}
		
	public Krug opisaniKrug()
	{
		return new Krug(this.srediste, this.dijagonala() / 2);
	}
	
	public String toString()
	{
		return "pravokutnik sa sredistem u " + this.srediste + " sirine " + this.sirina + 
				" i visine " + this.visina;
	}	
}
