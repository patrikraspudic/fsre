package Primjer_11;

import java.util.Random;

public class Sucelje 
{
	public static void main(String [] args)
	{
	
		GeometrijskiLik [] Likovi =
		{
			new Krug(new Tocka(), 3),
			new Krug(new Tocka(2, 2), 5),
			new Pravokutnik(new Tocka(3, 1), 5, 3),
			new Pravokutnik(new Tocka(), 1, 3), 
			new Kvadrat(new Tocka(), 6),
			new Kvadrat(new Tocka(4, 3), 5)
			// nije mogu�e instancirati su�elja
			// new GeometrijskiLik(new Tocka()),
			// new GeometrijskiLik(new Tocka(4, 0))		
		};
		
		for(int i = 0; i < Likovi.length; i++)
		{
			System.out.println(Likovi[i]);
			System.out.println("Povr�ina lika je " + Likovi[i].povrsina() + ".");
		}
		System.out.println("----------");		
		
		Random slucajniIzbor = new Random();
		for(int i = 0; i < 10; i++)
		{
			GeometrijskiLik SGL = Likovi[slucajniIzbor.nextInt(Likovi.length)];
			System.out.println(SGL);
			System.out.print("Povr�ina lika je " + SGL.povrsina() + ",");
			System.out.println(" a opseg lika je " + SGL.opseg() + ".");
		
			if(SGL instanceof Pravokutnik)
			{
				System.out.println("Opisani krug je: " + ((Pravokutnik)SGL).opisaniKrug());
			}
			else
			{
				System.out.println("Opisani kvadrat je: " + ((Krug)SGL).opisaniKvadrat());
			}				
			System.out.println("----------");	
		}
	}
}
