package Primjer_11;

public class Kvadrat extends Pravokutnik
{
	public double stranica;
	
	public Kvadrat(Tocka srediste, double stranica)
	{
		super(srediste, stranica, stranica);
		this.stranica = stranica;
	}
	
	public Kvadrat(final Kvadrat K)
	{
		super(K);
		this.stranica = K.stranica;
	}

	public double povrsina()
	{
		return this.stranica * this.stranica;
	}
	
	public double opseg()
	{
		return 4 * this.stranica;
	}
	
	public String toString()
	{
		return "Kvadrat sa sredistem u to�ki " + this.srediste + 
				" stranice " + this.stranica;
	}
}
