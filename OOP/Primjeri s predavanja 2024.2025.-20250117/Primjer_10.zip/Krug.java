package Primjer_10;

public class Krug extends GeometrijskiLik
{
	public double polumjer;
	
	public Krug(Tocka srediste, double polumjer)
	{
		super(srediste);
		this.polumjer = polumjer;
	}
	
	public Krug(final Krug K)
	{
		super(K);	
		this.polumjer = K.polumjer;
	}
	
	public void promijeniPolumjer(double noviPolumjer)
	{
		this.polumjer = noviPolumjer;
	}
	
	public double povrsina()
	{
		return this.polumjer * this.polumjer * Math.PI;
	}
	
	public double opseg()
	{
		return 2 * this.polumjer * Math.PI;
	}	
		
	public String toString()
	{
		return "krug, " + super.toString() + ", polumjer je " + this.polumjer;
	}
}
