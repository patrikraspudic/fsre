package Primjer_10;

// apstraktni razred ima barem jednu apstraktnu metodu 
// apstraktni razred ne dopu�ta instanciranje
public abstract class GeometrijskiLik 
{
	private Tocka srediste;
	
	public GeometrijskiLik(Tocka srediste)
	{
		this.srediste = srediste;
	}

	public GeometrijskiLik(GeometrijskiLik GL)
	{
		this.srediste = GL.srediste;
	}
	
	public Tocka vratiSrediste()
	{
		return this.srediste;
	}
	
	// apstraktna metoda nema tijelo nego samo zaglavlje
	abstract public double povrsina();
	
	// apstraktna metoda nema tijelo nego samo zaglavlje
	abstract public double opseg();
		
	public String toString()
	{
		return "sredi�te je u to�ki " + this.srediste;
	}
}
