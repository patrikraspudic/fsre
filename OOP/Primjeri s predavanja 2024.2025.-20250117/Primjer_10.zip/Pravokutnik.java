package Primjer_10;

public class Pravokutnik extends GeometrijskiLik
{
	public double sirina;
	public double visina;
		
	public Pravokutnik(Tocka srediste, double sirina, double visina)
	{
		super(srediste);
		this.visina = visina;
		this.sirina = sirina;
	}
	
	public Pravokutnik(final Pravokutnik P)
	{
		super(P);
		this.sirina = P.sirina;
		this.visina = P.visina;
	}
	
	public double povrsina()
	{
		return this.visina * this.sirina;
	}
	
	public double opseg()
	{
		return 2 * (this.visina + this.sirina);
	}	
	
	public double dijagonala()
	{
		return Math.sqrt(this.sirina * this.sirina + this.visina * this.visina);
	}
		
	public Krug opisaniKrug()
	{
		return new Krug(this.vratiSrediste(), this.dijagonala() / 2);
	}
	
	public String toString()
	{
		return "pravokutnik, " + super.toString() + ", sirina je " + this.sirina + 
				", a visina je " + this.visina;
	}
}
