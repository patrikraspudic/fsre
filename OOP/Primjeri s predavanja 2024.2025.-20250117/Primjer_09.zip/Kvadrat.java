package Primjer_09;

public class Kvadrat extends Pravokutnik
{
	double stranica;
	
	public Kvadrat(Tocka srediste, double stranica)
	{
		super(srediste, stranica, stranica);
		this.stranica = stranica;
	}
	
	public Kvadrat(final Kvadrat K)
	{
		super(K);
		this.stranica = K.stranica;
	}

	public double povrsina()
	{
		return this.stranica * this.stranica;
	}
	
	public String toString()
	{
		return "kvadrat, sredi�te je u to�ki " + this.vratiSrediste() + 
				", stranica je " + this.stranica;
	}
}

