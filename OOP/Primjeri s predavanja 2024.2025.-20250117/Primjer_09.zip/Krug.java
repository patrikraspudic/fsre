package Primjer_09;

public class Krug extends GeometrijskiLik
{
	public double polumjer;
	
	public Krug(Tocka srediste, double polumjer)
	{
		super(srediste);
		this.polumjer = polumjer;
	}
	
	public Krug(final Krug K)
	{
		//1. na�in
		super(K);	//poziva se konstruktor kopije razreda GeometrijskiLik jer je svaki krug ujedno i geometrijski lik
		
		//2. na�in
		// super(K.vratiSrediste());  	// poziva se konstruktor razreda GeometrijskiLik s to�kom kao ulaznim parametrom
		this.polumjer = K.polumjer;
	}
	
	public void promijeniPolumjer(double noviPolumjer)
	{
		this.polumjer = noviPolumjer;
	}
	
	public double povrsina()
	{
		return this.polumjer * this.polumjer * Math.PI;
	}
		
	public String toString()
	{
		return "krug, " + super.toString() + ", polumjer je " + this.polumjer;
	}
}
