package Primjer_11;

// apstraktni razred ima barem jednu apstraktnu metodu
public abstract class GeometrijskiLik 
{
	private Tocka srediste;
	
	public GeometrijskiLik(Tocka srediste)
	{
		this.srediste = srediste;
	}
	
	public GeometrijskiLik(final GeometrijskiLik GL)
	{
	    this.srediste = GL.srediste;
	}
	
	public Tocka vratiSrediste()
	{
		return srediste;
	}
	
	// apstraktna metoda nema tijelo
	public abstract double povrsina();
	
	public String toString()
	{	
		return "sredi�te je u to�ki " + this.srediste;
	}
}
