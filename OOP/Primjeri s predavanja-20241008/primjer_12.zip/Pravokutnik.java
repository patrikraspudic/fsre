package Primjer_12;

public class Pravokutnik implements GeometrijskiLik
{
	private Tocka srediste;
	private double sirina;
	private double visina;
	
	public Pravokutnik(Tocka srediste, double sirina, double visina)
	{
		this.srediste = srediste;
		this.sirina = sirina;
		this.visina = visina;
	}
	
	public Pravokutnik(final Pravokutnik P)
	{
		this.srediste = P.srediste;
		this.sirina = P.sirina;
		this.visina = P.visina;
	}
	
	// implementacija metoda su�elja GeometrijskiLik
	public double povrsina()
	{
		return this.sirina * this.visina;	
	}
	
	public double opseg()
	{
		return 2 * (this.sirina + this.visina);	
	}	
	
	public double dijagonala()
	{
		return Math.sqrt(this.sirina * this.sirina + this.visina * this.visina);
	}
	
	public String toString()
	{
		return "pravokutnik sa sredi�tem u " + this.srediste + " �irine " + this.sirina + " i visine " + this.visina; 
	}
	
	public Krug opisaniKrug()
	{
		return new Krug(this.srediste, this.dijagonala() / 2);
	}
}
