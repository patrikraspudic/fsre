package Primjer_12;

public class Kvadrat extends Pravokutnik
{
	public Tocka srediste;
	public double stranica;
	
	public Kvadrat(Tocka srediste, double stranica)
	{
		super(srediste, stranica, stranica);
		this.srediste = srediste;
		this.stranica = stranica;
	}
	
	public Kvadrat(final Kvadrat K)
	{
		super(K);
		this.srediste = K.srediste;
		this.stranica = K.stranica;
	}
	
	public double povrsina()
	{
		return this.stranica * this.stranica;
	}
	
	public double opseg()
	{
		return 4 * this.stranica;
	}

	public String toString()
	{
		return "kvadrat sa sredistem u to�ki " + this.srediste + " stranice " + this.stranica;
	}
}