package Primjer_12;

public interface Transformacija 
{	
	void pomak(double dx, double dy);
}
