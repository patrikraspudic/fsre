package Primjer_12;

// razred Tocka implementira su�elje Transformacija 
public class Tocka implements Transformacija
{
	private double x;
	private double y;
	
	public Tocka()
	{}
	
	public Tocka(double x, double y)
	{
		this.x = x;
		this.y = y;
	}
	
	public Tocka(final Tocka T)
	{
		this.x = T.x;
		this.y = T.y;
	}
	
	// definiranje metode implementiranog su�elja Transformacija
	public void pomak(double dx, double dy)
	{
		this.x += dx;
		this.y += dy;
	}
	
	public double udaljenost(Tocka T)
	{
		return Math.sqrt((this.x - T.x) * (this.x - T.x) + (this.y - T.y) * (this.y - T.y));
	}
	
	public String toString()
	{
		return "(" + this.x + ", " + this.y + ")";
	}

}
