package Primjer_12;

// razred Krug implementira su�elja GeometrijskiLik i Transformacija
public class Krug implements GeometrijskiLik, Transformacija
{
	public Tocka srediste;
	public double polumjer;
	
	public Krug(Tocka srediste, double polumjer)
	{
		this.srediste = srediste;
		this.polumjer = polumjer;
	}
	
	public Krug(final Krug K)
	{
		this.srediste = K.srediste;
		this.polumjer = K.polumjer;
	}
	
	public void promijeniPolumjer(double noviPolumjer)
	{
		this.polumjer = noviPolumjer;
	}
	
	// implementacija metoda su�elja GeometrijskiLik
	public double povrsina()
	{
		return this.polumjer * this.polumjer * Math.PI;
	}
	
	public double opseg()
	{
		return 2 * this.polumjer * Math.PI;
	}
	
	// implementacija metode su�elja Transformacija
	public void pomak(double dx, double dy)
	{
		this.srediste.pomak(dx, dy);
	}
	
	public Kvadrat opisaniKvadrat()
	{
		return new Kvadrat(this.srediste, 2 * this.polumjer);
	}
	
	public String toString()
	{
		return "krug sa sredi�tem u " + this.srediste + " i polumjera " + this.polumjer;
	}
}
