package Primjer_12;

public interface GeometrijskiLik 
{
	double povrsina();
	double opseg();
}
