

package Primjer_10;

import java.util.Random;

public class Nasljedjivanje 
{
	public static void main(String [] args)
	{
		// test razreda Tocka
		System.out.println("Za razred Tocka:");
		Tocka T1 = new Tocka();
		Tocka T2 = new Tocka (3.4, -2.6);
		Tocka T3 = new Tocka(T2);
		
		System.out.println(T1);
		System.out.println(T2);
		System.out.println(T3);
		System.out.println("-------------------");
		
		System.out.println("Udaljenost to�aka T1 i T2 je " + T1.udaljenost(T2) + ".");
		System.out.println("Udaljenost to�aka T2 i T3 je " + T2.udaljenost(T3) + ".");
		System.out.println("-------------------");
		
		T3.pomak(3.0, 4.0);
		System.out.println(T3);
		System.out.println("Udaljenost to�aka T2 i T3 je " + T2.udaljenost(T3) + ".");
		System.out.println("-------------------");

		// test razreda GeometrijskiLik
		System.out.println("Za razred GeometrijskiLik:");
		GeometrijskiLik GL1 = new GeometrijskiLik(T1);
		GeometrijskiLik GL2 = new GeometrijskiLik(T2);
		GeometrijskiLik GL3 = new GeometrijskiLik(GL2);
		
		System.out.println(GL1);
		System.out.println(GL2);
		System.out.println(GL3);
		System.out.println("-------------------");		
		
		System.out.println("Sredi�te geometrijskog lika GL1 je u to�ki " + GL1.vratiSrediste() + ".");
		System.out.println("Sredi�te geometrijskog lika GL2 je u to�ki " + GL2.vratiSrediste() + ".");
		System.out.println("Sredi�te geometrijskog lika GL3 je u to�ki " + GL3.vratiSrediste() + ".");
		System.out.println("-------------------");		
		
		System.out.println("Povr�ina geometrijskog lika GL2 je " + GL2.povrsina() + ".");
		System.out.println("-------------------");		
		
		T2.pomak(5, 5);
		System.out.println(T2);
		System.out.println("Sredi�te geometrijskog lika GL2 je u to�ki " + GL2.vratiSrediste() + ".");
		System.out.println("Sredi�te geometrijskog lika GL3 je u to�ki " + GL3.vratiSrediste() + ".");
		System.out.println("-------------------");		

		// test razreda Krug
		System.out.println("Za razred Krug:");
		Krug Kr1 = new Krug(T1, 3.0);
		Krug Kr2 = new Krug(T2, 5.0);
		Krug Kr3 = new Krug(Kr2);

		System.out.println(Kr1);
		System.out.println(Kr2);
		System.out.println(Kr3);
		System.out.println("-------------------");		
		
		Kr3.promijeniPolumjer(2.0);
		System.out.println(Kr3);
		System.out.println("-------------------");		
		
		System.out.println("Povr�ina kruga Kr1 je " + Kr1.povrsina() + ".");
		System.out.println("Povr�ina kruga Kr2 je " + Kr2.povrsina() + ".");
		System.out.println("Povr�ina kruga Kr3 je " + Kr3.povrsina() + ".");
		System.out.println("-------------------");		
		
		// test razreda Pravokutnik
		System.out.println("Za razred Pravokutnik:");
		Pravokutnik Pr1 = new Pravokutnik(T1, 3.0, 5.0);
		Pravokutnik Pr2 = new Pravokutnik(T2, 6.0, 8.0);
		Pravokutnik Pr3 = new Pravokutnik(Pr2);
		
		System.out.println(Pr1);
		System.out.println(Pr2);
		System.out.println(Pr3);
		System.out.println("-------------------");	

		System.out.println("Dijagonala pravokutnika Pr1 je " + Pr1.dijagonala() + ".");
		System.out.println("Dijagonala pravokutnika Pr2 je " + Pr2.dijagonala() + ".");
		System.out.println("-------------------");
		
		System.out.println("Povr�ina pravokutnika Pr1 je " + Pr1.povrsina() + ".");
		System.out.println("Povr�ina pravokutnika Pr2 je " + Pr2.povrsina() + ".");
		System.out.println("-------------------");

		System.out.println("Opisani krug za Pr1:");
		System.out.println(Pr1.opisaniKrug());
		System.out.println("Opisani krug za Pr2:");
		System.out.println(Pr2.opisaniKrug());
		System.out.println("-------------------");

		// test razreda Kvadrat
		System.out.println("Za razred Kvadrat:");
		Kvadrat Kv1 = new Kvadrat(T1, 6.0);
		Kvadrat Kv2 = new Kvadrat(T2, 4.0);
		Kvadrat Kv3 = new Kvadrat(Kv2);
		
		System.out.println(Kv1);
		System.out.println(Kv2);
		System.out.println(Kv3);
		System.out.println("-------------------");	

		System.out.println("Povr�ina kvadrata Kv1 je " + Kv1.povrsina() + ".");
		System.out.println("Povr�ina kvadrata Kv2 je " + Kv2.povrsina() + ".");
		System.out.println("-------------------");
		
		System.out.println("Opisani krug za Kv1:");
		System.out.println(Kv1.opisaniKrug());
		System.out.println("Opisani krug za Kv2:");
		System.out.println(Kv2.opisaniKrug());
		System.out.println("-------------------");
		
		GeometrijskiLik [] Likovi =
			{
				new Krug(new Tocka(), 3),
				new Krug(new Tocka(2, 2), 5),
				new Pravokutnik(new Tocka(3, 1), 5, 3),
				new Pravokutnik(new Tocka(), 1, 3),
				new Kvadrat(new Tocka(), 5),
				new Kvadrat(new Tocka(5, 1), 3),
				new GeometrijskiLik(new Tocka()),
				new GeometrijskiLik(new Tocka(6, 4))
			};
		
		for(int i = 0; i < Likovi.length; i++)
		{
			System.out.println(Likovi[i]);
			System.out.println("Povr�ina lika je " + Likovi[i].povrsina() + ".");
		}
		System.out.println("-------------------");
		
		Random slucajniIzbor = new Random();
		
		for(int i = 0; i < 10; i++)
		{
			GeometrijskiLik SGL = Likovi[slucajniIzbor.nextInt(Likovi.length)];
			System.out.println(SGL);
			System.out.println("Povr�ina lika je " + SGL.povrsina() + ".");
			
			if(SGL instanceof Pravokutnik)
			{
				System.out.println("Opisani krug je: " + ((Pravokutnik)SGL).opisaniKrug());
			}
			System.out.println("-------------------");
		}
		
			
	}
}
