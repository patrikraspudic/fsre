package Primjer_10;

public class Pravokutnik extends GeometrijskiLik
{
	private double sirina;
	private double visina;
	
	public Pravokutnik(Tocka srediste, double sirina, double visina)
	{
		super(srediste);
		this.sirina = sirina;
		this.visina = visina;
	}
	
	public Pravokutnik(final Pravokutnik P)
	{
		super(P);
		this.sirina = P.sirina;
		this.visina = P.visina;
	}
	
	public double povrsina()
	{
		return this.sirina * this.visina;	
	}
	
	public double dijagonala()
	{
		return Math.sqrt(this.sirina * this.sirina + this.visina * this.visina);
	}
	
	public String toString()
	{
		return "pravokutnik, " + super.toString() + ", �irina je " + this.sirina + ", a visina je " + this.visina; 
	}
	
	public Krug opisaniKrug()
	{
		return new Krug(this.vratiSrediste(), this.dijagonala() / 2);
	}
}
