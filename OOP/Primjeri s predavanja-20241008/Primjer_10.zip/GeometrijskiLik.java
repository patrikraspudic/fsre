package Primjer_10;

public class GeometrijskiLik 
{
	private Tocka srediste;
	
	public GeometrijskiLik(Tocka srediste)
	{
		// 1. na�in
		this.srediste = srediste;
		
		// 2. na�in
	    // this.srediste = new Tocka(srediste);
	}
	
	public GeometrijskiLik(final GeometrijskiLik GL)
	{
	    this.srediste = GL.srediste;
		
	    // ili
		// this.srediste = new Tocka(GL.srediste);
		
	    // ili
	    // this(GL.srediste);
	}
	
	public Tocka vratiSrediste()
	{
		return srediste;
	}
	
	public double povrsina()
	{
		return 0;
	}
	
	public String toString()
	{	
		return "sredi�te je u to�ki " + this.srediste;
	}
}
