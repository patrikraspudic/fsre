package Primjer_10;

public class Tocka 
{
	private double x;
	private double y;
	
	public Tocka()
	{}
	
	public Tocka(double x, double y)
	{
		this.x = x;
		this.y = y;
	}
	
	public Tocka(final Tocka T)
	{
		this.x = T.x;
		this.y = T.y;
	}
	
	public void pomak(double dx, double dy)
	{
		this.x += dx;
		this.y += dy;
	}
	
	public double udaljenost(Tocka T)
	{
		return Math.sqrt((this.x - T.x) * (this.x - T.x) + (this.y - T.y) * (this.y - T.y));
	}
	
	public String toString()
	{
		return "(" + this.x + ", " + this.y + ")";
	}

}
